// import "./sidebar.scss";
// import DashboardIcon from "@mui/icons-material/Dashboard";
// import PersonOutlineIcon from "@mui/icons-material/PersonOutline";
// import LocalShippingIcon from "@mui/icons-material/LocalShipping";
// import CreditCardIcon from "@mui/icons-material/CreditCard";
// import StoreIcon from "@mui/icons-material/Store";
// import CleaningServicesIcon from "@mui/icons-material/CleaningServices";
// import InsertChartIcon from "@mui/icons-material/InsertChart";
// import SettingsApplicationsIcon from "@mui/icons-material/SettingsApplications";
// import ExitToAppIcon from "@mui/icons-material/ExitToApp";
// import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";
// import SettingsSystemDaydreamOutlinedIcon from "@mui/icons-material/SettingsSystemDaydreamOutlined";
// import PsychologyOutlinedIcon from "@mui/icons-material/PsychologyOutlined";
// import AccountCircleOutlinedIcon from "@mui/icons-material/AccountCircleOutlined";
// import { Link } from "react-router-dom";
// import { DarkModeContext } from "../../context/darkModeContext";
// import { useContext } from "react";
// import { AuthContext } from "../../context/AuthContext";
// import Cookies from "js-cookie";

// // import { Link } from 'react-router-dom';

// const Sidebar = () => {
//   const HandleLogout = () => {
//     const { dispatch } = useContext(AuthContext); // Access dispatch from AuthContext

//     // Remove user from localStorage
//     localStorage.removeItem("user");

//     // Remove access_token cookie (if you're using cookies for token storage)
//     Cookies.remove("access_token");

//     // Dispatch the LOGOUT action to clear the user state
//     dispatch({ type: "LOGOUT" });

//     // Navigate to the homepage or login page
//     window.location.href = "/login"; // You can change this to "/" if needed
//   };
//   const { dispatch } = useContext(DarkModeContext);
//   return (
//     <div className="sidebar">
//       <div className="top">
//         <Link to="/" style={{ textDecoration: "none" }}>
//           <span className="logo">Moderator</span>
//         </Link>
//       </div>
//       <hr />
//       <div className="center">
//         <ul>
//           <p className="title">MAIN</p>
//           <li>
//             <DashboardIcon className="icon" />
//             <span>Dashboard</span>
//           </li>
//           <p className="title">LISTS</p>
//           <Link to="/users" style={{ textDecoration: "none" }}>
//             <li>
//               <PersonOutlineIcon className="icon" />
//               <span>Customers</span>
//             </li>
//           </Link>
//           {/* <Link to="/hotels" style={{ textDecoration: "none" }}>
//             <li>
//               <StoreIcon className="icon" />
//               <span>Hotels</span>
//             </li>
//           </Link> */}
//           <Link to="/rooms" style={{ textDecoration: "none" }}>
//             <li>
//               <CreditCardIcon className="icon" />
//               <span>Rooms</span>
//             </li>
//           </Link>
//           {/* Worker link */}
//           <Link to="/worker" style={{ textDecoration: "none" }}>
//             <li>
//               <CleaningServicesIcon className="icon" />
//               <span>Workers</span>
//             </li>
//           </Link>
//           <p className="title">USEFUL</p>
//           <li>
//             <InsertChartIcon className="icon" />
//             <span>Stats</span>
//           </li>
//           <li>
//             <NotificationsNoneIcon className="icon" />
//             <span>Notifications</span>
//           </li>
//           <p className="title">SERVICE</p>
//           {/* <li>
//             <SettingsSystemDaydreamOutlinedIcon className="icon" />
//             <span>System Health</span>
//           </li> */}
//           {/* <li>
//             <PsychologyOutlinedIcon className="icon" />
//             <span>Logs</span>
//           </li> */}
//           <li>
//             <SettingsApplicationsIcon className="icon" />
//             <span>Settings</span>
//           </li>
//           <p className="title">USER</p>
//           <li>
//             <AccountCircleOutlinedIcon className="icon" />
//             <span>Profile</span>
//           </li>
//           <li>
//             <div onClick={HandleLogout}>
//               <ExitToAppIcon className="icon" />
//               <span>Logout</span>
//             </div>
//           </li>
//         </ul>
//       </div>
//       <div className="bottom">
//         <div
//           className="colorOption"
//           onClick={() => dispatch({ type: "LIGHT" })}
//         ></div>
//         <div
//           className="colorOption"
//           onClick={() => dispatch({ type: "DARK" })}
//         ></div>
//       </div>
//     </div>
//   );
// };

// export default Sidebar;
import "./sidebar.scss";
import DashboardIcon from "@mui/icons-material/Dashboard";
import PersonOutlineIcon from "@mui/icons-material/PersonOutline";
import CreditCardIcon from "@mui/icons-material/CreditCard";
import CleaningServicesIcon from "@mui/icons-material/CleaningServices";
import InsertChartIcon from "@mui/icons-material/InsertChart";
import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";
import SettingsApplicationsIcon from "@mui/icons-material/SettingsApplications";
import ExitToAppIcon from "@mui/icons-material/ExitToApp";
import AccountCircleOutlinedIcon from "@mui/icons-material/AccountCircleOutlined";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux"; // Redux hooks
import { logout } from "../../store/authSlice";
import { useContext } from "react";
import { DarkModeContext } from "../../context/darkModeContext"; // Dark mode context
import Cookies from "js-cookie";

const Sidebar = () => {
  const dispatch = useDispatch();
  const { user } = useSelector((state) => state.auth);

  // Dark Mode Context
  const { dispatch: darkModeDispatch } = useContext(DarkModeContext);

  // Logout function using Redux and Cookies
  const handleLogout = () => {
    dispatch(logout()); // Dispatch logout action to Redux
    Cookies.remove("access_token"); // Remove the access token from cookies
    window.location.href = "/login"; // Redirect to login page
  };

  // Theme change handlers
  const handleThemeChange = (isDark) => {
    if (isDark) {
      darkModeDispatch({ type: "DARK" }); // Set dark mode using DarkModeContext
    } else {
      darkModeDispatch({ type: "LIGHT" }); // Set light mode using DarkModeContext
    }
  };

  return (
    <div className="sidebar">
      <div className="top">
        <Link to="/" style={{ textDecoration: "none" }}>
          <span className="logo">Moderator</span>
        </Link>
      </div>
      <hr />
      <div className="center">
        <ul>
          <p className="title">MAIN</p>
          <li>
            <DashboardIcon className="icon" />
            <span>Dashboard</span>
          </li>
          <p className="title">LISTS</p>
          <Link to="/users" style={{ textDecoration: "none" }}>
            <li>
              <PersonOutlineIcon className="icon" />
              <span>Customers</span>
            </li>
          </Link>
          <Link to="/rooms" style={{ textDecoration: "none" }}>
            <li>
              <CreditCardIcon className="icon" />
              <span>Rooms</span>
            </li>
          </Link>
          <Link to="/worker" style={{ textDecoration: "none" }}>
            <li>
              <CleaningServicesIcon className="icon" />
              <span>Workers</span>
            </li>
          </Link>
          <p className="title">USEFUL</p>
          <li>
            <InsertChartIcon className="icon" />
            <span>Stats</span>
          </li>
          <li>
            <NotificationsNoneIcon className="icon" />
            <span>Notifications</span>
          </li>
          <p className="title">SERVICE</p>
          <li>
            <SettingsApplicationsIcon className="icon" />
            <span>Settings</span>
          </li>
          <p className="title">USER</p>
          <li>
            <AccountCircleOutlinedIcon className="icon" />
            <span>Profile</span>
          </li>
          <li>
            <div onClick={handleLogout}>
              <ExitToAppIcon className="icon" />
              <span>Logout</span>
            </div>
          </li>
        </ul>
      </div>
      <div className="bottom">
        <div
          className="colorOption"
          onClick={() => handleThemeChange(false)}
        ></div>
        <div
          className="colorOption"
          onClick={() => handleThemeChange(true)}
        ></div>
      </div>
    </div>
  );
};

export default Sidebar;
