import React, { useContext, useEffect, useState } from 'react';
import Sidebar from "../../components/sidebar/Sidebar";
import Navbar from "../../components/navbar/Navbar";
import { AuthContext } from '../../context/AuthContext';
import { DataGrid } from '@mui/x-data-grid';
import './table.scss';

const WorkerList = () => {
  const [workers, setWorkers] = useState([]);
  const [error, setError] = useState(null);

  // Access AuthContext to get the user and token
  const { user, loading } = useContext(AuthContext);

  useEffect(() => {
    // Hardcoded worker data for testing purposes
    const hardcodedWorkers = [
      {
        _id: 'Wx21',
        name: 'Ramesh',
        assignedRoomId: 'Room 5x',
        isFree: false,
      },
      {
        _id: 'Wx45',
        name: 'Suri Babu',
        assignedRoomId: 'Room 2y',
        isFree: false,
      },
      {
        _id: 'Wx233',
        name: 'Rahul',
        assignedRoomId: 'N/A',
        isFree: true,
      },
      {
        _id: 'Wx4',
        name: 'Lokesh',
        assignedRoomId: 'Room104',
        isFree: false,
      },
      {
        _id: 'Wx5',
        name: 'Giri',
        assignedRoomId: 'N/A',
        isFree: true,
      },
    ];

    // Simulating data fetching
    setWorkers(hardcodedWorkers);
  }, [user]);

  if (loading) return <div>Loading...</div>;
  if (error) {
    return <div className="error">Error: {error}</div>;
  }

  // Define columns for the DataGrid
  const workerColumns = [
    { field: 'id', headerName: 'ID', width: 200 },
    { field: 'name', headerName: 'Name', width: 150 },
    { field: 'assignedRoomId', headerName: 'Assigned Room', width: 150 },
    {
      field: 'isFree',
      headerName: 'Availability',
      width: 150,
      renderCell: (params) => (
        <div className={`cellWithStatus ${params.row.isFree ? 'free' : 'busy'}`}>
          {params.row.isFree ? 'Free' : 'Busy'}
        </div>
      ),
    },
    {
      field: 'assign',
      headerName: 'Assign',
      width: 150,
      renderCell: (params) => (
        <button
          className="assign-button" // Use the SCSS class
          onClick={() => alert(`Assigning ${params.row.name}`)} // Placeholder function
        >
          Assign
        </button>
      ),
    },
  ];

  // Map workers data to rows
  const rows = workers.map((worker) => ({
    id: worker._id,
    name: worker.name,
    assignedRoomId: worker.assignedRoomId,
    isFree: worker.isFree,
  }));

  console.log('Rows to be displayed in DataGrid:', rows);

  return (
    <div className="workerListContainer">
      <Sidebar />
      <div className="workerListContent">
        <Navbar />

        <div className="datatable">
          <div className="datatableTitle">Worker List</div>
          <DataGrid
            rows={rows}
            columns={workerColumns}
            pageSize={9}
            rowsPerPageOptions={[9]}
            checkboxSelection
            getRowId={(row) => row.id}
            loading={loading || (workers.length === 0 && !error)}
            components={{
              NoRowsOverlay: () => (
                <div style={{ padding: '16px', textAlign: 'center' }}>
                  {error ? 'Error loading data' : 'No workers available'}
                </div>
              ),
            }}
          />
        </div>
      </div>
    </div>
  );
};

export default WorkerList;
