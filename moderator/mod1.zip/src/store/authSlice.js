import { createSlice } from "@reduxjs/toolkit";
import Cookies from "js-cookie";

// Initial state: checks if the 'isModerator' cookie is set to 'true', else defaults to 'false'
const initialState = {
  isModerator: Cookies.get("isModerator") === "true" || false,
};

const moderatorAuthSlice = createSlice({
  name: "moderatorAuth",
  initialState,
  reducers: {
    // Login action: sets isModerator to true and stores the cookie for 7 days
    login(state) {
      state.isModerator = true;
      Cookies.set("isModerator", "true", { expires: 7 }); // Cookie expires in 7 days
    },
    // Logout action: sets isModerator to false and removes the cookie
    logout(state) {
      state.isModerator = false;
      Cookies.remove("isModerator");
    },
  },
});

// Exporting actions
export const { login, logout } = moderatorAuthSlice.actions;

// Exporting the reducer
export default moderatorAuthSlice.reducer;
