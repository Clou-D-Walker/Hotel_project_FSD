import { configureStore } from "@reduxjs/toolkit";
import moderatorAuthReducer from "./authSlice";

const store = configureStore({
  reducer: {
    moderatorAuth: moderatorAuthReducer,
  },
});

export default store;
