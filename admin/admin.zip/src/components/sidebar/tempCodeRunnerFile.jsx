<li>
            <ExitToAppIcon className="icon" />
            <span>Logout</span>
          </li>