import User from "../models/User.js";
import bcrypt from "bcryptjs";
import { createError } from "../utils/error.js";
import jwt from "jsonwebtoken";

export const register = async (req, res, next) => {
  try {
    const salt = bcrypt.genSaltSync(10);
    const hash = bcrypt.hashSync(req.body.password, salt);

    const newUser = new User({
      ...req.body,
      password: hash,
    });

    await newUser.save();
    res.status(200).redirect("http://localhost:3000");
    // res.status(200).redirect("/otp");
  } catch (err) {
    next(err);
  }
};
export const login = async (req, res, next) => {
  try {
    const user = await User.findOne({ username: req.body.username });
    if (!user) return next(createError(404, "User not found!"));

    const isPasswordCorrect = await bcrypt.compare(
      req.body.password,
      user.password
    );
    if (!isPasswordCorrect)
      return next(createError(400, "Wrong password or username!"));

    const token = jwt.sign(
      { id: user._id, isAdmin: user.isAdmin, isModerator: user.isModerator },
      process.env.JWT
      // secret key
    );

    const { password, isAdmin, isModerator, ...otherDetails } = user._doc;
    res
      .cookie("access_token", token, {
        httpOnly: true,
      })
      .status(200)
      .json({ details: { ...otherDetails }, isAdmin, isModerator });
  } catch (err) {
    next(err);
  }
};

// export const verifyOTP = async (req, res, next) => {
//   try {
//     const { email, otp } = req.body;

//     const user = await User.findOne({ email });
//     if (!user) {
//       return res.status(404).send("User not found.");
//     }

//     if (user.otp !== otp) {
//       return res.status(400).send("Invalid OTP.");
//     }

//     user.isVerified = true; // Mark user as verified
//     user.otp = null; // Clear the OTP
//     await user.save();

//     res.status(200).send("OTP verified successfully.");
//   } catch (err) {
//     next(err);
//   }
// };

// const transporter = nodemailer.createTransport({
//   service: "gmail", // You can use other services like Outlook, etc.
//   secure: true,
//   auth: {
//     user: "lawlovesnicorobin@gmail.com", // Replace with your email
//     pass: "pjdb mawv oqlz axln", // Replace with your email password (use app-specific password if required)
//   },
// });

// eftz eukm wavh bkgc
